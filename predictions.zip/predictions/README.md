# Model Predictions

This directory contains *corrected* test set predictions (that is, predictions on `data/corrected/{lang}/test.jsonl`) for GTT and IterX models trained in each of the following three settings (described in the paper):

- `tgt_auto`: The model is trained on the *uncorrected* target language training data (`data/multimuc_v1.0/uncorrected/{lang}/train.jsonl`). The uncorrected target language dev data is also used.
- `tgt_man`: The model is trained on the *corrected* target language training data (`data/multimuc_v1.0/corrected/{lang}/train.jsonl`). The corrected target language dev data is also used.
- `bi`: The model is trained on the *corrected* target language trainig data, *plus* the gold English MUC-4 data. Only corrected target language data is used for dev (same as `tgt_man`).

Our predictions are based on a single training run for each (setting, language) pair, and the directory for each such pair contains the following three files:

- `test_preds.json`: The JSON-formatted corrected test set predictions. These files follow the format of the GTT predictions (`preds_gtt.out`) released [here](https://github.com/xinyadu/gtt/blob/master/model_gtt/preds_gtt.out). The top-level keys in these files correspond to document IDs, though they are wrangled into a different format.
- `eval_iterx_ceaf_ree.out`: CEAF-REE scores for `test_preds.json` (see our paper for details).
- `eval_iterx_ceaf_rme.out`: CEAF-RME scores for `test_preds.json` (see our paper for details).
